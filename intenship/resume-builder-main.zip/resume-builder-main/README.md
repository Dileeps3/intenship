# resume-builder!
![Screenshot (78)](https://github.com/mani2244/resume-builder/assets/105537048/131b3499-bbfb-4a7f-8ac3-49c20492bc5b)
